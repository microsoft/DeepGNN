# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""DeepGNN modules to work with torch models."""
