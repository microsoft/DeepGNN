# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

# flake8: noqa
from .factory import run_dist
