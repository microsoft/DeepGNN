# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Shared torch.nn modules."""
