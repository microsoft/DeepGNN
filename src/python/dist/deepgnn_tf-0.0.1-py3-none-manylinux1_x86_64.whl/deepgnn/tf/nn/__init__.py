# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""NN modules for TF models."""
